﻿namespace QLKS
{
    partial class UC_SANPHAM
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupPanel_ContenSP = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.panelEx_DetailSP = new DevComponents.DotNetBar.PanelEx();
            this.value_TGBH = new DevComponents.DotNetBar.LabelX();
            this.value_GiaHienHanh = new DevComponents.DotNetBar.LabelX();
            this.value_MauSac = new DevComponents.DotNetBar.LabelX();
            this.value_nhaSX = new DevComponents.DotNetBar.LabelX();
            this.labelX_MauSac = new DevComponents.DotNetBar.LabelX();
            this.labelX_nhSX = new DevComponents.DotNetBar.LabelX();
            this.labelX_TGBaoHanh = new DevComponents.DotNetBar.LabelX();
            this.labelX_Gia = new DevComponents.DotNetBar.LabelX();
            this.rImage_Avatar = new DevComponents.DotNetBar.Controls.ReflectionImage();
            this.groupPanel_ContenSP.SuspendLayout();
            this.panelEx_DetailSP.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupPanel_ContenSP
            // 
            this.groupPanel_ContenSP.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel_ContenSP.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel_ContenSP.Controls.Add(this.panelEx_DetailSP);
            this.groupPanel_ContenSP.Controls.Add(this.rImage_Avatar);
            this.groupPanel_ContenSP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel_ContenSP.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.groupPanel_ContenSP.Location = new System.Drawing.Point(0, 0);
            this.groupPanel_ContenSP.Name = "groupPanel_ContenSP";
            this.groupPanel_ContenSP.Size = new System.Drawing.Size(262, 315);
            // 
            // 
            // 
            this.groupPanel_ContenSP.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel_ContenSP.Style.BackColorGradientAngle = 90;
            this.groupPanel_ContenSP.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel_ContenSP.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_ContenSP.Style.BorderBottomWidth = 1;
            this.groupPanel_ContenSP.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel_ContenSP.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_ContenSP.Style.BorderLeftWidth = 1;
            this.groupPanel_ContenSP.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_ContenSP.Style.BorderRightWidth = 1;
            this.groupPanel_ContenSP.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_ContenSP.Style.BorderTopWidth = 1;
            this.groupPanel_ContenSP.Style.Class = "";
            this.groupPanel_ContenSP.Style.CornerDiameter = 4;
            this.groupPanel_ContenSP.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel_ContenSP.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel_ContenSP.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel_ContenSP.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel_ContenSP.StyleMouseDown.Class = "";
            this.groupPanel_ContenSP.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel_ContenSP.StyleMouseOver.Class = "";
            this.groupPanel_ContenSP.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel_ContenSP.TabIndex = 0;
            this.groupPanel_ContenSP.Text = "Ten Dong May";
            // 
            // panelEx_DetailSP
            // 
            this.panelEx_DetailSP.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx_DetailSP.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.panelEx_DetailSP.Controls.Add(this.value_TGBH);
            this.panelEx_DetailSP.Controls.Add(this.value_GiaHienHanh);
            this.panelEx_DetailSP.Controls.Add(this.value_MauSac);
            this.panelEx_DetailSP.Controls.Add(this.value_nhaSX);
            this.panelEx_DetailSP.Controls.Add(this.labelX_MauSac);
            this.panelEx_DetailSP.Controls.Add(this.labelX_nhSX);
            this.panelEx_DetailSP.Controls.Add(this.labelX_TGBaoHanh);
            this.panelEx_DetailSP.Controls.Add(this.labelX_Gia);
            this.panelEx_DetailSP.Location = new System.Drawing.Point(9, 190);
            this.panelEx_DetailSP.Name = "panelEx_DetailSP";
            this.panelEx_DetailSP.Size = new System.Drawing.Size(239, 100);
            this.panelEx_DetailSP.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx_DetailSP.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelEx_DetailSP.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx_DetailSP.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx_DetailSP.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx_DetailSP.Style.GradientAngle = 80;
            this.panelEx_DetailSP.TabIndex = 1;
            // 
            // value_TGBH
            // 
            // 
            // 
            // 
            this.value_TGBH.BackgroundStyle.Class = "";
            this.value_TGBH.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.value_TGBH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.value_TGBH.Location = new System.Drawing.Point(123, 72);
            this.value_TGBH.Name = "value_TGBH";
            this.value_TGBH.Size = new System.Drawing.Size(112, 23);
            this.value_TGBH.TabIndex = 7;
            this.value_TGBH.Text = "labelX4";
            // 
            // value_GiaHienHanh
            // 
            // 
            // 
            // 
            this.value_GiaHienHanh.BackgroundStyle.Class = "";
            this.value_GiaHienHanh.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.value_GiaHienHanh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.value_GiaHienHanh.Location = new System.Drawing.Point(123, 48);
            this.value_GiaHienHanh.Name = "value_GiaHienHanh";
            this.value_GiaHienHanh.Size = new System.Drawing.Size(112, 23);
            this.value_GiaHienHanh.TabIndex = 6;
            this.value_GiaHienHanh.Text = "labelX3";
            // 
            // value_MauSac
            // 
            // 
            // 
            // 
            this.value_MauSac.BackgroundStyle.Class = "";
            this.value_MauSac.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.value_MauSac.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.value_MauSac.Location = new System.Drawing.Point(123, 26);
            this.value_MauSac.Name = "value_MauSac";
            this.value_MauSac.Size = new System.Drawing.Size(112, 23);
            this.value_MauSac.TabIndex = 5;
            this.value_MauSac.Text = "labelX2";
            // 
            // value_nhaSX
            // 
            // 
            // 
            // 
            this.value_nhaSX.BackgroundStyle.Class = "";
            this.value_nhaSX.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.value_nhaSX.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.value_nhaSX.Location = new System.Drawing.Point(124, 5);
            this.value_nhaSX.Name = "value_nhaSX";
            this.value_nhaSX.Size = new System.Drawing.Size(112, 23);
            this.value_nhaSX.TabIndex = 4;
            this.value_nhaSX.Text = "labelX1";
            // 
            // labelX_MauSac
            // 
            // 
            // 
            // 
            this.labelX_MauSac.BackgroundStyle.Class = "";
            this.labelX_MauSac.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX_MauSac.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelX_MauSac.ForeColor = System.Drawing.Color.Navy;
            this.labelX_MauSac.Location = new System.Drawing.Point(5, 27);
            this.labelX_MauSac.Name = "labelX_MauSac";
            this.labelX_MauSac.Size = new System.Drawing.Size(118, 23);
            this.labelX_MauSac.TabIndex = 3;
            this.labelX_MauSac.Text = "Màu sắc";
            // 
            // labelX_nhSX
            // 
            // 
            // 
            // 
            this.labelX_nhSX.BackgroundStyle.Class = "";
            this.labelX_nhSX.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX_nhSX.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelX_nhSX.ForeColor = System.Drawing.Color.Navy;
            this.labelX_nhSX.Location = new System.Drawing.Point(6, 6);
            this.labelX_nhSX.Name = "labelX_nhSX";
            this.labelX_nhSX.Size = new System.Drawing.Size(118, 23);
            this.labelX_nhSX.TabIndex = 2;
            this.labelX_nhSX.Text = "Nhà sản xuất";
            // 
            // labelX_TGBaoHanh
            // 
            // 
            // 
            // 
            this.labelX_TGBaoHanh.BackgroundStyle.Class = "";
            this.labelX_TGBaoHanh.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX_TGBaoHanh.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelX_TGBaoHanh.ForeColor = System.Drawing.Color.Navy;
            this.labelX_TGBaoHanh.Location = new System.Drawing.Point(5, 72);
            this.labelX_TGBaoHanh.Name = "labelX_TGBaoHanh";
            this.labelX_TGBaoHanh.Size = new System.Drawing.Size(118, 23);
            this.labelX_TGBaoHanh.TabIndex = 1;
            this.labelX_TGBaoHanh.Text = "Thời gian bảo hành";
            // 
            // labelX_Gia
            // 
            // 
            // 
            // 
            this.labelX_Gia.BackgroundStyle.Class = "";
            this.labelX_Gia.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX_Gia.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelX_Gia.ForeColor = System.Drawing.Color.Navy;
            this.labelX_Gia.Location = new System.Drawing.Point(6, 49);
            this.labelX_Gia.Name = "labelX_Gia";
            this.labelX_Gia.Size = new System.Drawing.Size(118, 23);
            this.labelX_Gia.TabIndex = 0;
            this.labelX_Gia.Text = "Giá bán hiện hành";
            // 
            // rImage_Avatar
            // 
            // 
            // 
            // 
            this.rImage_Avatar.BackgroundStyle.Class = "";
            this.rImage_Avatar.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rImage_Avatar.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.rImage_Avatar.Image = global::QLKS.Properties.Resources.Laptop;
            this.rImage_Avatar.Location = new System.Drawing.Point(10, 3);
            this.rImage_Avatar.Name = "rImage_Avatar";
            this.rImage_Avatar.Size = new System.Drawing.Size(235, 180);
            this.rImage_Avatar.TabIndex = 0;
            // 
            // UC_SANPHAM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupPanel_ContenSP);
            this.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Style3D;
            this.Name = "UC_SANPHAM";
            this.Size = new System.Drawing.Size(262, 315);
            this.groupPanel_ContenSP.ResumeLayout(false);
            this.panelEx_DetailSP.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel_ContenSP;
        private DevComponents.DotNetBar.Controls.ReflectionImage rImage_Avatar;
        private DevComponents.DotNetBar.PanelEx panelEx_DetailSP;
        private DevComponents.DotNetBar.LabelX labelX_Gia;
        private DevComponents.DotNetBar.LabelX labelX_TGBaoHanh;
        private DevComponents.DotNetBar.LabelX labelX_MauSac;
        private DevComponents.DotNetBar.LabelX labelX_nhSX;
        private DevComponents.DotNetBar.LabelX value_GiaHienHanh;
        private DevComponents.DotNetBar.LabelX value_MauSac;
        private DevComponents.DotNetBar.LabelX value_nhaSX;
        private DevComponents.DotNetBar.LabelX value_TGBH;
    }
}
