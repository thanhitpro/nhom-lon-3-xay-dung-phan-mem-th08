- Cai dat cac phan mem nhu nhom 29 trinh bay
- Mo SQL Server, tao database(trong file .sql da co day du du lieu), database ten la ESTORE
- Mo Visual Studio 2008, dung Server Explorer connect toi database
   + Xoa file Estore.dbml, add lai file nay, keo tu server explorer cac table can thiet
   + Vao file app.config cua EStoreDAO, chinh connection string, phan DataSource la server name cua may ban

Good luck !