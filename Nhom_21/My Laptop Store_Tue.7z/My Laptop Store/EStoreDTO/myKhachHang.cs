﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EStoreDTO
{
    public class myKhachHang
    {  
        string m_sTenKhachHang;

        public string STenKhachHang
        {
            get { return m_sTenKhachHang; }
            set { m_sTenKhachHang = value; }
        }

        string m_sNgaySinh;

        public string SNgaySinh
        {
            get { return m_sNgaySinh; }
            set { m_sNgaySinh = value; }
        }

        string m_sCMND;

        public string SCMND
        {
            get { return m_sCMND; }
            set { m_sCMND = value; }
        }

        string m_sGioiTinh;

        public string SGioiTinh
        {
            get { return m_sGioiTinh; }
            set { m_sGioiTinh = value; }
        }

        string m_sDiaChi;

        public string SDiaChi
        {
            get { return m_sDiaChi; }
            set { m_sDiaChi = value; }
        }

        string m_sEmail;

        public string SEmail
        {
            get { return m_sEmail; }
            set { m_sEmail = value; }
        }

        string m_sSoDienThoai;

        public string SSoDienThoai
        {
            get { return m_sSoDienThoai; }
            set { m_sSoDienThoai = value; }
        }
    }
    }
