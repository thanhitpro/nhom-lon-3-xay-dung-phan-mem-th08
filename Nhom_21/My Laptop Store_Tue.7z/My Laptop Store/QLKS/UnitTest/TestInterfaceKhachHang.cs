﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using EStoreBUS;
using EStoreDTO;
using System.Windows.Forms;

namespace QLKS.UnitTest
{
    [TestFixture]
    class TestInterfaceKhachHang
    {
        private DevComponents.DotNetBar.Controls.DataGridViewX dataGridView;
        [Test]
        public void khoiTaoThemKhachHangTest()
        {
            InterfaceKhachHang interfaceKhachHangTest = new InterfaceKhachHang();
            List<String> gioiTinh = new List<string>();
            gioiTinh.Add("Nam");
            gioiTinh.Add("Nữ");
            Assert.AreEqual(gioiTinh, interfaceKhachHangTest.khoiTaoThemKhachHang(), "lỗi khi so sánh giới tính nam");
        }



        [Test]
        public void layDataGridViewKhachHangTest()
        {            
            InterfaceKhachHang _interfaceKhachHangTest = new InterfaceKhachHang();
            List<myKhachHang> dsKhachHang = new List<myKhachHang>();
            myKhachHangBUS khachHang_BUS = new myKhachHangBUS();
            dsKhachHang = khachHang_BUS.LayDanhSachKhachHang();
             //////////////////////////////////////////////////////////////////////////
            //Tạo DataGridView dataGridViewKhachHang
            //////////////////////////////////////////////////////////////////////////
            DevComponents.DotNetBar.Controls.DataGridViewX dataGridViewKhachHang = new DevComponents.DotNetBar.Controls.DataGridViewX();

            DataGridViewTextBoxColumn TenKhachHang = new DataGridViewTextBoxColumn();
            TenKhachHang.HeaderText = "Tên Khách Hàng";
            TenKhachHang.Name = "TenKhachHang";            

            DataGridViewTextBoxColumn GioiTinh = new DataGridViewTextBoxColumn();
            GioiTinh.HeaderText = "Giới Tính";
            GioiTinh.Name = "GioiTinh";

            DataGridViewTextBoxColumn CMND = new DataGridViewTextBoxColumn();
            CMND.HeaderText = "CMND";
            CMND.Name = "CMND";

            DataGridViewTextBoxColumn DiaChi = new DataGridViewTextBoxColumn();
            CMND.HeaderText = "Địa chỉ";
            CMND.Name = "DiaChi";

            DataGridViewTextBoxColumn Email = new DataGridViewTextBoxColumn();
            CMND.HeaderText = "Email";
            CMND.Name = "Email";

            DataGridViewTextBoxColumn Phone = new DataGridViewTextBoxColumn();
            CMND.HeaderText = "Phone";
            CMND.Name = "Phone";

            DataGridViewTextBoxColumn NgaySinh = new DataGridViewTextBoxColumn();
            CMND.HeaderText = "Ngày Sinh";
            CMND.Name = "NgaySinh";

            dataGridViewKhachHang.Columns.AddRange(new DataGridViewTextBoxColumn[] {
            TenKhachHang,
            GioiTinh,
            CMND,
            DiaChi,
            Email,
            Phone,
            NgaySinh});
            //////////////////////////////////////////////////////////////////////////

            for (int i = 0; i < dsKhachHang.Count; ++i)
                dataGridViewKhachHang.Rows.Add(dsKhachHang[i].STenKhachHang, dsKhachHang[i].SGioiTinh, dsKhachHang[i].SCMND, dsKhachHang[i].SDiaChi, dsKhachHang[i].SEmail, dsKhachHang[i].SSoDienThoai, dsKhachHang[i].SNgaySinh);
            dataGridView = _interfaceKhachHangTest.layDataGridViewKhachHang(dataGridViewKhachHang);

            myKhachHang khachHangDauTien = new myKhachHang
            {
                STenKhachHang = "Tống Hoàng Quốc Nhật",
                SNgaySinh = "08/03/1990",
                SGioiTinh = "Nam",
                SCMND = "272065189",
                SDiaChi = "Biên Hòa",
                SEmail = "qnhata3@yahoo.com",
                SSoDienThoai = "0977014007"
            };
            Assert.AreEqual(khachHangDauTien.STenKhachHang, dataGridView.Rows[0].Cells[0].Value, "Lỗi do không có khách hàng nào thỏa");
        }
    }
}
