﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QLKS
{
    public partial class UC_THONGTINNHOM : UserControl
    {
        public UC_THONGTINNHOM()
        {
            InitializeComponent();
        }
    }
}
