﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QLKS
{
    public class InterfaceKhachHang
    {
      
        public List<String> khoiTaoThemKhachHang()
        {
            List<string> comboboxTemp = new List<string>();
            comboboxTemp.Add("Nam");
            comboboxTemp.Add("Nữ");
            return comboboxTemp;
        }
        public DevComponents.DotNetBar.Controls.DataGridViewX layDataGridViewKhachHang(DevComponents.DotNetBar.Controls.DataGridViewX _dataGirdViewX)
        {
            return _dataGirdViewX;
        }
    }
}
